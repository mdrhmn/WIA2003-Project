directory = "/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/"
filesArr = ["jak.txt","bkk.txt","hkg.txt","tpe.txt","tok.txt","kor.txt","pek.txt"]
stopWordsDirectory = directory + "stopwords.txt"
wordCount_before = [0,0,0,0,0,0,0]
index = 0

print("################################################ STOP WORDS REMOVAL ################################################")
for i in range(0, len(filesArr), 1):
    fileDirectory = directory + filesArr[index]
    
    # Count total words after stop words removal
    totalCount = 0
    with open(fileDirectory, encoding = "utf8" ) as word_list:
        words = word_list.read().lower().split()

    for i in words:
        totalCount = totalCount + 1

    print("Total word count of {0} before stop words removal: {1}".format(filesArr[index], totalCount))
    wordCount_before[index] = totalCount

    # KMP Algorithm
    def KMPSearch(pat, txt): 
        M = len(pat) 
        N = len(txt)
        det = []

        # create lps[] that will hold the longest prefix suffix 
        lps = [0]*M 
        j = 0 # index for pat[] 

        # Preprocess the pattern (calculate lps[] array) 
        computeLPSArray(pat, M, lps) 

        i = 0 # index for txt[] 
        while i < N: 
            if pat[j] == txt[i]: 
                i += 1
                j += 1

            if j==M: 
                # If the pattern matched, put the index inside the list
                det.append(i-j)
                j = lps[j-1]        

            # mismatch after j matches 
            elif i < N and pat[j] != txt[i]: 
                # Do not match lps[0..lps[j-1]] characters, 
                # they will match anyway 
                if j != 0: 
                    j = lps[j-1] 
                else:
                    i += 1

        # return all the indexes of matched string
        return det

    def computeLPSArray(pat, M, lps): 
        len = 0 # length of the previous longest prefix suffix 

        lps[0] # lps[0] is always 0 
        i = 1

        # the loop calculates lps[i] for i = 1 to M-1 
        while i < M: 
            if pat[i]== pat[len]: 
                len += 1
                lps[i] = len
                i += 1
            else: 
                
                if len != 0: 
                    len = lps[len-1] 

                else: 
                    lps[i] = 0
                    i += 1

    # # file with stopwords
    f1 = open(stopWordsDirectory, "r+",encoding="utf8") 

    # # city text file
    f2 = open(fileDirectory, "r+", encoding="utf8")

    file1_raw = f1.read()
    file2_raw = f2.read().lower()

    file1_words = file1_raw.split()
    file2_words_SWRemoved = file2_raw.split()

    # Remove punctuations
    punctuations = string.punctuation
    punctuations += '“”‘’—'
    table = str.maketrans('', '', punctuations)
    stripped = [w.translate(table) for w in file2_words_SWRemoved]
    file2_words = (" ").join(stripped)

    for w in file1_words:
        newtext = ""
        a = 0
        m = 0
        pat = " " + w + " "

        ind = KMPSearch(pat, file2_words)
        
        # if the words matched
        if len(ind)>0:
            while a < len(ind):
                newtext += file2_words[m: ind[a]]
                m = len(w)+ind[a]+1
                a += 1
            newtext += file2_words[m:]

            # To update text after removing stop word z
            file2_words = newtext 

    # Write edited text file content back
    f2_w = open(fileDirectory, "w", encoding="utf8") 
    f2_w.write(file2_words)
    f2_w.close()
    f1.close()
    f2.close()

    # Count total words after stop words removal
    totalCount = 0
    with open(fileDirectory, encoding = "utf8") as word_list:
        words = word_list.read().lower().split()

    for i in words:
        totalCount = totalCount + 1
    
    print("Total word count of {0} after stop words removal: {1}\n".format(filesArr[index], totalCount))

    index = index + 1

print("################################################ +VE/-VE WORDS ANALYSIS ################################################")
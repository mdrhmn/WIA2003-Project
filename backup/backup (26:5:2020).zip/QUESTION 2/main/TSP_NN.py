# TSP_5: NEAREST NEIGHBOUR (WORKING, APPROX. RESULT)

import numpy as np
from pytsp.constants import Constants
from geopy.distance import geodesic


# Coordinate
c_KLIA_KUL = (2.7456, 101.7072) # 0. Kuala Lumpur International Airport, Kuala Lumpur
c_SHIA_JAK = (-6.1275, 106.6537) # 1. Soekarno-Hatta International Airport, Jakarta
c_SUVA_BKK = (13.6900, 100.7501) # 2. Suvarnabhumi Airport, Bangkok
c_CLK_HKG = (22.3080, 113.9185) # 3. Chek Lap Kok International Airport, Hong Kong
c_TAO_TPE = (25.0797, 121.2342)  # 4. Taoyuan International Airport, Taipei
c_HND_TOK = (35.5494, 139.7798) # 5. Haneda International Airport, Tokyo
c_ICN_KOR = (37.4602, 126.4407) # 6. Incheon International Airport, Seoul
c_BDA_PEK = (39.5098, 116.4105) # 7. Beijing Daxing International Airport, Beijing

shortest_distance_NN = 0

def nearest_neighbour_tsp(graph, starting_point = 0):
    """
    Nearest Neighbour TSP algorithm
    Args:
        graph: 2d numpy array
        starting_point: index of starting node
    Returns:
        tour approximated by nearest Neighbour tsp algorithm
    Examples:
        >>> import numpy as np
        >>> graph = np.array([[  0, 300, 250, 190, 230],
        >>>                   [300,   0, 230, 330, 150],
        >>>                   [250, 230,   0, 240, 120],
        >>>                   [190, 330, 240,   0, 220],
        >>>                   [230, 150, 120, 220,   0]])
        >>> nearest_neighbour_tsp(graph)
    """
    number_of_nodes = len(graph)
    unvisited_nodes = list(range(number_of_nodes))
    unvisited_nodes.remove(starting_point)
    visited_nodes = [starting_point]

    while number_of_nodes > len(visited_nodes):
        Neighbours = find_neighbours(
            np.array(graph[visited_nodes[-1]]))

        not_visited_neighbours = list(
            set(Neighbours[0].flatten()).intersection(unvisited_nodes))
        
        # pick the one travelling salesman has not been to yet
        try:
            next_node = find_next_neighbour(
                not_visited_neighbours, np.array(graph[visited_nodes[-1]]))
        except ValueError:
            print("Nearest Neighbour algorithm couldn't find a Neighbour that hasn't been to yet")
            return
        visited_nodes.append(next_node)
        unvisited_nodes.remove(next_node)

        # Append going back to starting node
        if (len(unvisited_nodes) == 0):
            visited_nodes.append(0)
            next_node = find_next_neighbour(
                not_visited_neighbours, np.array(graph[visited_nodes[-1]]))

    return visited_nodes


def find_neighbours(array_of_edges_from_node):
    """
        Find the list of all Neighbours for given node from adjacency matrix.
        Args:
            array_of_edges_from_node (np.array):
        Returns:
            List [] of all Neighbours for given node
        """
    mask = (array_of_edges_from_node > 0) & (
        array_of_edges_from_node < Constants.MAX_WEIGHT_OF_EDGE)

    return np.where(np.squeeze(np.asarray(mask)))


def find_next_neighbour(not_visited_neighbours, array_of_edges_from_node):
    """
    Args:
        not_visited_neighbours:
        array_of_edges_from_node:
    Returns:
    """
    global shortest_distance_NN

    # last node in visited_nodes is where the traveling salesman is.   
    cheapest_path = np.argmin(
        array_of_edges_from_node[not_visited_neighbours])

    shortest_distance_NN += array_of_edges_from_node[not_visited_neighbours][cheapest_path]
    return not_visited_neighbours[cheapest_path]

# graph  = [[0, (geodesic(c_KLIA_KUL, c_SHIA_JAK).km), (geodesic(c_KLIA_KUL, c_SUVA_BKK).km), (geodesic(c_KLIA_KUL, c_CLK_HKG).km), (geodesic(c_KLIA_KUL, c_TAO_TPE).km), (geodesic(c_KLIA_KUL, c_HND_TOK).km), (geodesic(c_KLIA_KUL, c_ICN_KOR).km), (geodesic(c_KLIA_KUL, c_BDA_PEK).km)], # Kuala Lumpur International Airport, Kuala Lumpur
#             [(geodesic(c_KLIA_KUL, c_SHIA_JAK).km), 0, (geodesic(c_SHIA_JAK, c_SUVA_BKK).km), (geodesic(c_SHIA_JAK, c_CLK_HKG).km), (geodesic(c_SHIA_JAK, c_TAO_TPE).km), (geodesic(c_SHIA_JAK, c_HND_TOK).km), (geodesic(c_SHIA_JAK, c_ICN_KOR).km), (geodesic(c_SHIA_JAK, c_BDA_PEK).km)], # Soekarno-Hatta International Airport, Jakarta
#             [(geodesic(c_KLIA_KUL, c_SUVA_BKK).km), (geodesic(c_SHIA_JAK, c_SUVA_BKK).km), 0, (geodesic(c_SUVA_BKK, c_CLK_HKG).km), (geodesic(c_SUVA_BKK, c_TAO_TPE).km), (geodesic(c_SUVA_BKK, c_HND_TOK).km), (geodesic(c_SUVA_BKK, c_ICN_KOR).km) , (geodesic(c_SUVA_BKK, c_BDA_PEK).km)], # Suvarnabhumi Airport, Bangkok
#             [(geodesic(c_KLIA_KUL, c_CLK_HKG).km), (geodesic(c_SHIA_JAK, c_CLK_HKG).km), (geodesic(c_SUVA_BKK, c_CLK_HKG).km), 0, (geodesic(c_CLK_HKG, c_TAO_TPE).km), (geodesic(c_CLK_HKG, c_HND_TOK).km), (geodesic(c_CLK_HKG, c_ICN_KOR).km), (geodesic(c_CLK_HKG, c_BDA_PEK).km)], # Chek Lap Kok International Airport, Hong Kong
#             [(geodesic(c_KLIA_KUL, c_TAO_TPE).km), (geodesic(c_SHIA_JAK, c_TAO_TPE).km) , (geodesic(c_SUVA_BKK, c_TAO_TPE).km), (geodesic(c_CLK_HKG, c_TAO_TPE).km), 0, (geodesic(c_TAO_TPE, c_HND_TOK).km), (geodesic(c_TAO_TPE, c_ICN_KOR).km), (geodesic(c_TAO_TPE, c_BDA_PEK).km)], # Taoyuan International Airport, Taipei
#             [(geodesic(c_KLIA_KUL, c_HND_TOK).km), (geodesic(c_SHIA_JAK, c_HND_TOK).km), (geodesic(c_SUVA_BKK, c_HND_TOK).km), (geodesic(c_CLK_HKG, c_HND_TOK).km), (geodesic(c_TAO_TPE, c_HND_TOK).km), 0, (geodesic(c_HND_TOK, c_ICN_KOR).km), (geodesic(c_HND_TOK, c_BDA_PEK).km)], # Haneda International Airport, Tokyo
#             [(geodesic(c_KLIA_KUL, c_ICN_KOR).km), (geodesic(c_SHIA_JAK, c_ICN_KOR).km), (geodesic(c_SUVA_BKK, c_ICN_KOR).km), (geodesic(c_CLK_HKG, c_ICN_KOR).km), (geodesic(c_TAO_TPE, c_ICN_KOR).km), (geodesic(c_HND_TOK, c_ICN_KOR).km), 0, (geodesic(c_ICN_KOR, c_BDA_PEK).km)], # Incheon International Airport, Seoul
#             [(geodesic(c_KLIA_KUL, c_BDA_PEK).km), (geodesic(c_SHIA_JAK, c_BDA_PEK).km), (geodesic(c_SUVA_BKK, c_BDA_PEK).km) , (geodesic(c_CLK_HKG, c_BDA_PEK).km), (geodesic(c_TAO_TPE, c_BDA_PEK).km), (geodesic(c_HND_TOK, c_BDA_PEK).km), (geodesic(c_ICN_KOR, c_BDA_PEK).km), 0]] # Beijing Daxing International Airport, Beijing

# print(nearest_neighbour_tsp(graph))
# print(shortest_distance)

def read_distances(filename):
    dists = []
    with open(filename, 'r') as f:
        for line in f:
            # Skip comments
            if line[0] == '#':
                continue

            dists.append(list(map(float, map(str.strip, line.split(' ')))))

    return dists

# Number of nodes
N = 8

cities_list = ["KUL", "JAK", "BKK", "HKG", "TPE", "TOK", "KOR", "PEK"]
text_directory = "/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/test/input.txt"

dists = read_distances(text_directory)

shortest_route_NN = nearest_neighbour_tsp(dists)

print("NEAREST NEIGHBOUR ALGORITHM:")
print("Shortest distance    : {} km".format(shortest_distance_NN))
print("Shortest path (index):", end=' ')
for i in range(N + 1):
    if (i + 1 < N + 1):
        print(shortest_route_NN[i], end=' -> ')
    else:
        print(shortest_route_NN[i], end=' (and vice versa)\n')

print("Shortest path (nodes):", end=' ')
for i in range(N + 1):
    if (i + 1 < N + 1):
        print(cities_list[shortest_route_NN[i]], end=' -> ')
    else:
        print(cities_list[shortest_route_NN[i]],
              end=' (and vice versa)\n')
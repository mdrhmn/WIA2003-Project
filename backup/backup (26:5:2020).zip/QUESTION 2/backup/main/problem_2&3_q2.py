import matplotlib.pyplot as plt
import numpy as np
from collections import deque, namedtuple
from geopy.distance import geodesic
from gmplot import *
import string

######################################################### PROBLEM 2 #########################################################

# Coordinates
c_KLIA_KUL = (2.7456, 101.7072) # 0. Kuala Lumpur International Airport, Kuala Lumpur
c_SHIA_JAK = (-6.1275, 106.6537) # 1. Soekarno-Hatta International Airport, Jakarta
c_SUVA_BKK = (13.6900, 100.7501) # 2. Suvarnabhumi Airport, Bangkok
c_CLK_HKG = (22.3080, 113.9185) # 3. Chek Lap Kok International Airport, Hong Kong
c_TAO_TPE = (25.0797, 121.2342)  # 4. Taoyuan International Airport, Taipei
c_HND_TOK = (35.5494, 139.7798) # 5. Haneda International Airport, Tokyo
c_ICN_KOR = (37.4602, 126.4407) # 6. Incheon International Airport, Seoul
c_BDA_PEK = (39.5098, 116.4105) # 7. Beijing Daxing International Airport, Beijing

# Filter stops words from the text you found ---------------------------------------------------------------------------------------------------------------------
directory = "/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/"
filesArr = ["jak.txt","bkk.txt","hkg.txt","tpe.txt","tok.txt","kor.txt","pek.txt"]
stopWordsDirectory = directory + "stopwords.txt"
wordCount_before = [0,0,0,0,0,0,0]
index = 0

print("################################################ STOP WORDS REMOVAL ################################################")
for i in range(0, len(filesArr), 1):
    fileDirectory = directory + filesArr[index]
    
    totalCount = 0
    with open(fileDirectory, encoding = "utf8" ) as word_list:
        words = word_list.read().lower().split()

    for i in words:
        totalCount = totalCount + 1

    print("Total word count of {0} before stop words removal: {1}".format(filesArr[index], totalCount))
    wordCount_before[index] = totalCount

    # file with stopwords
    f1 = open(stopWordsDirectory, "r") 
    
    # transport text file
    f2 = open(fileDirectory, "r+")
    
    file1_raw = f1.read()
    file2_raw = f2.read().lower()

    file1_words = file1_raw.split()
    file2_words = file2_raw.split()

    # Remove stop words
    for w in file1_words:
        for x in  file2_words:
            file2_raw = file2_raw.replace(" " + w + " ", " ")


    file2_words_SWRemoved = file2_raw.split()

    # Remove punctuations
    punctuations = string.punctuation
    punctuations += '“”‘’—'

    table = str.maketrans('', '', punctuations)
    stripped = [w.translate(table) for w in file2_words_SWRemoved]
    f2_w = open(fileDirectory, "w") 

    # Write edited text file content back 
    f2_w.write((" ").join(stripped))
    f2_w.close()
    f1.close()
    f2.close()

    totalCount = 0
    with open(fileDirectory, encoding = "utf8") as word_list:
        words = word_list.read().lower().split()

    for i in words:
        totalCount = totalCount + 1
    
    print("Total word count of {0} after stop words removal: {1}\n".format(filesArr[index], totalCount))

    index = index + 1

print("################################################ +VE/-VE WORDS ANALYSIS ################################################")
# Compare words in the webpages with the positive, negative and neutral English words using a String Matching algorithm

# JAKARTA: --------------------------------------------------------------------------------------------------------------------------------------------------------
# jak_pos = ['growth','grow','grew','optimistic','sufficient','highest','higher','expanded','rise','rising','high-income','easing']
# jak_neg = ['shave','downturn','u-turn','slowdown','lowest','lower','burden','weakening','weaken','deficit','worsen','worst']
jak_pos = ['growth','grow','grew','optimistic','sufficient','highest','higher','expanded','rise','rising','high-income','easing','growth','supporting','supported','equitable','maintain','sufficient','better','advantage']
jak_neg = ['shave','downturn','fell','slowdown','lowest','risk','fall','weakening','weaken','deficit','worsen','worst','burden','stress','downfall','decline','risk','risks','declining','decline']
jak_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
jak_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

with open("/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/jak.txt", encoding="utf8") as word_list:
    words = word_list.read().lower().split()

jak_posCount = 0
jak_negCount = 0
totalCount_jak = 0

for i in words:
    totalCount_jak = totalCount_jak + 1
    if i in jak_pos:
        jak_posCount = jak_posCount + 1
        jak_pos_f[jak_pos.index(i)] = jak_pos_f[jak_pos.index(i)] + 1

    if i in jak_neg:
        jak_negCount = jak_negCount + 1
        jak_neg_f[jak_neg.index(i)] = jak_neg_f[jak_neg.index(i)] + 1

print("Total word count in jak.txt: {0}".format(totalCount_jak))
print("Total positive word count in jak.txt: {0}\n".format(jak_posCount))
print("List of positive words in jak.txt based on 10 articles:\n")

index = 0
for i in range(len(jak_pos)):  
    strWord = "[" +  jak_pos[index] + "]"
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, jak_pos_f[index]))
    index = index + 1

print("Total negative word count in jak.txt: {0}\n".format(jak_negCount))
print("List of negative words in jak.txt based on 10 articles:\n")

index = 0
for i in range(len(jak_neg)):  
    strWord = "[" +  jak_neg[index] + "]" 
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, jak_neg_f[index]))
    index = index + 1

print("---------------------------------------------------------------------------------------------------------------------")

# BANGKOK: --------------------------------------------------------------------------------------------------------------------------------------------------------
# bkk_pos =['normal', 'maintain', 'strong', 'plan', 'positive', 'increasing', 'spike', 'rise', 'sufficient', 'stable', 'reliable', 'manageable']
# bkk_neg = ['irregularity', 'falling', 'weak', 'damage', 'damaging', 'reeling', 'collapse', 'drop', 'loss', 'losses', 'slowdown', 'risk']
bkk_pos = ['normal', 'maintain', 'strong', 'plan', 'plans' 'positive', 'increased', 'spike', 'rise', 'sufficient', 'stable', 'reliable', 'manageable', 'surged', 'spiked', 'soared', 'rose', 'relief', 'expand', 'accelerated']
bkk_neg = ['risks', 'irregularity', 'falling', 'weak', 'weakest', 'damage', 'damaging', 'reeling', 'collapse', 'drop', 'loss', 'losses', 'slowdown', 'risk', 'negative', 'critical', 'slower', 'fell', 'stop', 'fall']
bkk_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
bkk_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

with open("/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/bkk.txt", encoding="utf8") as word_list:
    words = word_list.read().lower().split()

bkk_posCount = 0
bkk_negCount = 0
totalCount_bkk = 0

for i in words:
    totalCount_bkk = totalCount_bkk + 1
    if i in bkk_pos:
        bkk_posCount = bkk_posCount + 1
        bkk_pos_f[bkk_pos.index(i)] = bkk_pos_f[bkk_pos.index(i)] + 1

    if i in bkk_neg:
        bkk_negCount = bkk_negCount + 1
        bkk_neg_f[bkk_neg.index(i)] = bkk_neg_f[bkk_neg.index(i)] + 1


print("Total word count in bkk.txt: {0}".format(totalCount_bkk))
print("Total positive word count in bkk.txt: {0}\n".format(bkk_posCount))
print("List of positive words in bkk.txt based on 10 articles:\n")

index = 0
for i in range(len(bkk_pos)):  
    strWord = "[" +  bkk_pos[index] + "]"
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, bkk_pos_f[index]))
    index = index + 1

print("Total negative word count in bkk.txt: {0}\n".format(bkk_negCount))
print("List of negative words in bkk.txt based on 10 articles:\n")

index = 0
for i in range(len(bkk_neg)):  
    strWord = "[" +  bkk_neg[index] + "]" 
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, bkk_neg_f[index]))
    index = index + 1

print("---------------------------------------------------------------------------------------------------------------------")

# HONG KONG: -------------------------------------------------------------------------------------------------------------------------------------------------------
# hkg_pos = ['rise', 'support', 'spur', 'stimulating', 'boost', 'increase', 'increased', 'rebooting', 'relieve', 'development', 'grow', 'better']
# hkg_neg = ['deteriorating', 'falling', 'worse', 'weakened', 'slowing', 'crisis', 'threat', 'deficit', 'slow', 'reeling', 'critical', 'worrying']
hkg_pos = ['rise', 'maintain', 'supporting', 'stability', 'recover', 'bounce', 'restore', 'save', 'fund', 'boost', 'stimulating', 'increase', 'increased', 'rebooting', 'developing', 'develop', 'relieve', 'grow', 'better', 'stimulate']
hkg_neg = ['deteriorating', 'falling', 'worse', 'weakening', 'slowing', 'unemployment', 'threat', 'deficit', 'risk', 'reduced', 'lower', 'weakening', 'crisis', 'recession', 'downturn', 'unrest', 'fell',  'slowing', 'reeling', 'critical']
hkg_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
hkg_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

with open("/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/hkg.txt", encoding="utf8") as word_list:
    words = word_list.read().lower().split()

hkg_posCount = 0
hkg_negCount = 0
totalCount_hkg = 0

for i in words:
    totalCount_hkg = totalCount_hkg + 1
    if i in hkg_pos:
        hkg_posCount = hkg_posCount + 1
        hkg_pos_f[hkg_pos.index(i)] = hkg_pos_f[hkg_pos.index(i)] + 1

    if i in hkg_neg:
        hkg_negCount = hkg_negCount + 1
        hkg_neg_f[hkg_neg.index(i)] = hkg_neg_f[hkg_neg.index(i)] + 1

print("Total word count in hkg.txt: {0}".format(totalCount_hkg))
print("Total positive word count in hkg.txt: {0}\n".format(hkg_posCount))
print("List of positive words in hkg.txt based on 10 articles:\n")

index = 0
for i in range(len(hkg_pos)):  
    strWord = "[" +  hkg_pos[index] + "]"
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, hkg_pos_f[index]))
    index = index + 1

print("Total negative word count in hkg.txt: {0}\n".format(hkg_negCount))
print("List of negative words in hkg.txt based on 10 articles:\n")

index = 0
for i in range(len(hkg_neg)):  
    strWord = "[" +  hkg_neg[index] + "]" 
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, hkg_neg_f[index]))
    index = index + 1

print("---------------------------------------------------------------------------------------------------------------------")

# TAIPEI: -------------------------------------------------------------------------------------------------------------------------------------------------------
# tpe_pos = ['coordinate', 'authorised', 'grow', 'expand', 'increase', 'sufficient', 'secure', 'high', 'up', 'stability', 'revive', 'maintaining']
# tpe_neg = ['lowered', 'downgrade', 'uncertainty', 'down', 'crisis', 'canceled', 'fallen', 'losses', 'subsides', 'critical', 'recession', 'fallout']
# tpe_pos = ['ramped', 'authorised', 'growing', 'expand', 'increase', 'sufficient', 'secure', 'high', 'shoring', 'stability', 'revive', 'maintaining', 'soared', 'rise', 'rising', 'increased', 'surged', 'strong',  'maintain', 'revised']
# tpe_neg = ['lowered', 'downgrade', 'uncertainty', 'down', 'crisis', 'canceled', 'fallen', 'losses', 'subsides', 'slow', 'critical', 'recession', 'fall', 'interrupt', 'reduced', 'fell', 'dropped', 'plunge', 'lower', 'downgraded']
tpe_pos = ['ramped', 'authorised', 'growing', 'expand', 'increase', 'sufficient', 'secure', 'high', 'shoring', 'stability', 'revive', 'maintaining', 'soared', 'rise', 'rising', 'increased', 'surged', 'strong',  'maintain', 'revised']
tpe_neg = ['lowered', 'downgrade', 'uncertainty', 'cut', 'crisis', 'canceled', 'fallen', 'losses', 'subsides', 'slow', 'low', 'recession', 'worst', 'interrupt', 'reduced', 'fell', 'dropped', 'plunge', 'lower', 'downgraded']
tpe_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
tpe_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

with open("/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/tpe.txt", encoding="utf8") as word_list:
    words = word_list.read().lower().split()

tpe_posCount = 0
tpe_negCount = 0
totalCount_tpe = 0

for i in words:
    totalCount_tpe = totalCount_tpe + 1
    if i in tpe_pos:
        tpe_posCount = tpe_posCount + 1
        tpe_pos_f[tpe_pos.index(i)] = tpe_pos_f[tpe_pos.index(i)] + 1

    if i in tpe_neg:
        tpe_negCount = tpe_negCount + 1
        tpe_neg_f[tpe_neg.index(i)] = tpe_neg_f[tpe_neg.index(i)] + 1

print("Total word count in tpe.txt: {0}".format(totalCount_tpe))
print("Total positive word count in tpe.txt: {0}\n".format(tpe_posCount))
print("List of positive words in tpe.txt based on 10 articles:\n")

index = 0
for i in range(len(tpe_pos)):  
    strWord = "[" +  tpe_pos[index] + "]"
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, tpe_pos_f[index]))
    index = index + 1

print("Total negative word count in tpe.txt: {0}\n".format(tpe_negCount))
print("List of negative words in tpe.txt based on 10 articles:\n")

index = 0
for i in range(len(tpe_neg)):  
    strWord = "[" +  tpe_neg[index] + "]" 
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, tpe_neg_f[index]))
    index = index + 1

print("---------------------------------------------------------------------------------------------------------------------")

# TOKYO: -------------------------------------------------------------------------------------------------------------------------------------------------------
# tok_pos = ['deploy','raising','forestall','funded','protected','overcome','helped','upgrades','growth','grew','recouped','recovery']
# tok_neg = ['stagnation','crisis','stagnate','risks','recession','losses','hurt','loss','cancellation','worse','risk','conflicts']
tok_pos = ['deploy','raising','raised','raises','greater','recovering','expanded','improvement','improve','expansion','expanding','forestall','funded','protected','overcome','helped','upgrades','improved','recouped','recovery']
tok_neg = ['stagnation','crisis','stagnate','risks','recession','losses','hurt','loss','cancellation','worse','risk','conflicts','worsens','delayed','negative','lower','sicker','bad','drop','disruption']
tok_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
tok_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

with open("/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/tok.txt", encoding="utf8") as word_list:
    words = word_list.read().lower().split()

tok_posCount = 0
tok_negCount = 0
totalCount_tok = 0

for i in words:
    totalCount_tok = totalCount_tok + 1
    if i in tok_pos:
        tok_posCount = tok_posCount + 1
        tok_pos_f[tok_pos.index(i)] = tok_pos_f[tok_pos.index(i)] + 1

    if i in tok_neg:
        tok_negCount = tok_negCount + 1
        tok_neg_f[tok_neg.index(i)] = tok_neg_f[tok_neg.index(i)] + 1

print("Total word count in tok.txt: {0}".format(totalCount_tok))
print("Total positive word count in tok.txt: {0}\n".format(tok_posCount))
print("List of positive words in tok.txt based on 10 articles:\n")

index = 0
for i in range(len(tok_pos)):  
    strWord = "[" +  tok_pos[index] + "]"
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, tok_pos_f[index]))
    index = index + 1

print("Total negative word count in tok.txt: {0}\n".format(tok_negCount))
print("List of negative words in tok.txt based on 10 articles:\n")

index = 0
for i in range(len(tok_neg)):  
    strWord = "[" +  tok_neg[index] + "]" 
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, tok_neg_f[index]))
    index = index + 1

print("---------------------------------------------------------------------------------------------------------------------")

# SEOUL: -------------------------------------------------------------------------------------------------------------------------------------------------------
# kor_pos = ['recovery','raise','prevention','recover','rebound','positive','efforts','stronger','expansion','expand','expansionary','ensure']
# kor_neg = ['suffer','suffered','recession','severe','setbacks','suspended','distrupting','delaying','shutdowns','damage','critical','fallout']
kor_pos = ['recovery','raise','prevention','recover','rebound','improved','efforts','stronger','additional','rose','expansionary','ensure','helped','stabilization','improving','expended','improvement','sufficiently','substantial','gain']
kor_neg = ['suffer','suffered','recession','severe','setbacks','suspended','warns','delaying','delayed','shutdowns','damage','critical','fallout','dropped','problematic','crisis','negatively','hit','worse','falling']
kor_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
kor_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

with open("/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/kor.txt", encoding="utf8") as word_list:
    words = word_list.read().lower().split()

kor_posCount = 0
kor_negCount = 0
totalCount_kor = 0

for i in words:
    totalCount_kor = totalCount_kor + 1
    if i in kor_pos:
        kor_posCount = kor_posCount + 1
        kor_pos_f[kor_pos.index(i)] = kor_pos_f[kor_pos.index(i)] + 1

    if i in kor_neg:
        kor_negCount = kor_negCount + 1
        kor_neg_f[kor_neg.index(i)] = kor_neg_f[kor_neg.index(i)] + 1

print("Total word count in kor.txt: {0}".format(totalCount_kor))
print("Total positive word count in kor.txt: {0}\n".format(kor_posCount))
print("List of positive words in kor.txt based on 10 articles:\n")

index = 0
for i in range(len(kor_pos)):  
    strWord = "[" +  kor_pos[index] + "]"
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, kor_pos_f[index]))
    index = index + 1

print("Total negative word count in kor.txt: {0}\n".format(kor_negCount))
print("List of negative words in kor.txt based on 10 articles:\n")

index = 0
for i in range(len(kor_neg)):  
    strWord = "[" +  kor_neg[index] + "]" 
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, kor_neg_f[index]))
    index = index + 1

print("---------------------------------------------------------------------------------------------------------------------")

# BEIJING: -------------------------------------------------------------------------------------------------------------------------------------------------------
# pek_pos = ['growth','increase','supporting','increasing','stabilizing','maintained','grow','grew','improvement','upwards','boost','upgrade']
# pek_neg = ['decline','collapse','warning','dropped','fell','declining','contract','contraction','drop','bottom','weaken','suffered']
pek_pos = ['growth','recovery','supporting','increasing','stabilizing','maintained','grow','grew','improvement','upwards','boost','upgraded','achieving','stability','increasing','sustainably','expand','recovery','strengthened','positively']
pek_neg = ['decline','collapse','imbalance','dropped','fell','debt','contract','drop','bottom','weak','suffered','stressed','risk','scandals','degradation','tension','declines','difficult','reducing','weaker']
pek_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
pek_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

with open("/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/pek.txt", encoding="utf8") as word_list:
    words = word_list.read().lower().split()

pek_posCount = 0
pek_negCount = 0
totalCount_pek = 0

for i in words:
    totalCount_pek = totalCount_pek + 1
    if i in pek_pos:
        pek_posCount = pek_posCount + 1
        pek_pos_f[pek_pos.index(i)] = pek_pos_f[pek_pos.index(i)] + 1

    if i in pek_neg:
        pek_negCount = pek_negCount + 1
        pek_neg_f[pek_neg.index(i)] = pek_neg_f[pek_neg.index(i)] + 1

print("Total word count in pek.txt: {0}".format(totalCount_pek))
print("Total positive word count in pek.txt: {0}\n".format(pek_posCount))
print("List of positive words in pek.txt based on 10 articles:\n")

index = 0
for i in range(len(pek_pos)):  
    strWord = "[" +  pek_pos[index] + "]"
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, pek_pos_f[index]))
    index = index + 1

print("Total negative word count in pek.txt: {0}\n".format(pek_negCount))
print("List of negative words in pek.txt based on 10 articles:\n")

index = 0
for i in range(len(pek_neg)):  
    strWord = "[" +  pek_neg[index] + "]" 
    print("Word: {:<17s}Frequency: {:<10d}\n".format(strWord, pek_neg_f[index]))
    index = index + 1

print("---------------------------------------------------------------------------------------------------------------------")

# Plot line/scatter/histogram graphs related to the word count using Plotly (word count, stop words)
totalCount = [totalCount_jak, totalCount_bkk, totalCount_hkg, totalCount_tpe, totalCount_tok, totalCount_kor, totalCount_pek]
labels = ('Jakarta', 'Bangkok', 'Hong Kong', 'Taipei', 'Tokyo', 'Seoul', 'Beijing')
y_pos = np.arange(len(labels))

plt.title('Cities Word Counts')
plt.xlabel('Cities')
plt.ylabel('Number of Words')

plt.plot(labels, wordCount_before, '-', label='Before stop words removal')
plt.plot(labels, totalCount, '-', label='After stop words removal')
plt.legend()

plt.scatter(y_pos, wordCount_before, color=['black', 'red', 'green', 'blue', 'cyan','yellow','orange'])
plt.scatter(y_pos, totalCount, color=['black', 'red', 'green', 'blue', 'cyan','yellow','orange'])

for x,y in zip(labels, wordCount_before):

    label = "{:.2f}".format(y)
    plt.annotate(label, # this is the text
                 (x,y), # this is the point to label
                 textcoords="offset points", # how to position the text
                 xytext=(0,10), # distance from text to points (x,y)
                 ha='center')

for x,y in zip(labels,totalCount):

    label = "{:.2f}".format(y)
    plt.annotate(label, # this is the text
                 (x,y), # this is the point to label
                 textcoords="offset points", # how to position the text
                 xytext=(0,10), # distance from text to points (x,y)
                 ha='center')
plt.show()

# Plot histogram graphs of positive and negative words found in the webpages.
N = 7
ind = np.arange(N)  # the x locations for the groups
width = 0.27       # the width of the bars

fig = plt.figure()
ax = fig.add_subplot(111)

yvals = [jak_posCount, bkk_posCount, hkg_posCount, tpe_posCount, tok_posCount, kor_posCount, pek_posCount]
rects1 = ax.bar(ind, yvals, width, color='g')
zvals = [jak_negCount, bkk_negCount, hkg_negCount, tpe_negCount, tok_negCount, kor_negCount, pek_negCount]
rects2 = ax.bar(ind+width, zvals, width, color='r')

ax.set_xlabel('Cities')
ax.set_ylabel('Number of words')
plt.title('Number of Positive & Negative Words Per Cities')
ax.set_xticks(ind+width)
ax.set_xticklabels(('Jakarta', 'Bangkok', 'Hong Kong', 'Taipei', 'Tokyo', 'Seoul', 'Beijing'))
ax.legend((rects1[0], rects2[0]), ('Positive', 'Negative'))

def autolabel(rects):
    for rect in rects:
        h = rect.get_height()
        ax.text(rect.get_x()+rect.get_width()/2., 1.05*h, '%d'%int(h),
                ha='center', va='bottom')

autolabel(rects1)
autolabel(rects2)

plt.show()

# Give an algorithmic conclusion regarding the sentiment of those articles
print("Polarity of different cities:\n")

# JAKARTA
polarity_jak = (jak_posCount - jak_posCount)/totalCount_jak
if(polarity_jak < 0):
    polarity_jak = -1
else: 
    polarity_jak = 1
print("Polarity of Jakarta: {}".format(polarity_jak))

# BANGKOK
polarity_bkk = (bkk_posCount - bkk_negCount)/totalCount_bkk
if(polarity_bkk < 0):
    polarity_bkk = -1
else: 
    polarity_bkk = 1
print ("Polarity of Bangkok: {}".format(polarity_bkk))

# HONG KONG
polarity_hkg = (hkg_posCount - hkg_negCount)/totalCount_hkg
if(polarity_hkg < 0):
    polarity_hkg = -1
else: 
    polarity_hkg = 1
print ("Polarity of Hong Kong: {}".format(polarity_hkg))

# TAIPEI
polarity_tpe = (tpe_posCount - tpe_negCount)/totalCount_tpe
if(polarity_tpe < 0):
    polarity_tpe = -1
else: 
    polarity_tpe = 1
print ("Polarity of Taipei: {}".format(polarity_tpe))

# TOKYO
polarity_tok = (tok_posCount - tok_negCount)/totalCount_tok
if(polarity_tok < 0):
    polarity_tok = -1
else: 
    polarity_tok = 1
print ("Polarity of Tokyo: {}".format(polarity_tok))

# SEOUL
polarity_kor = (kor_posCount - kor_negCount)/totalCount_kor
if(polarity_kor < 0):
    polarity_kor = -1
else: 
    polarity_kor = 1
print ("Polarity of Seoul: {}".format(polarity_kor))

# BEIJING
polarity_pek = (pek_posCount - pek_negCount)/totalCount_pek
if(polarity_pek < 0):
    polarity_pek = -1
else: 
    polarity_pek = 1
print ("Polarity of Beijing: {}\n".format(polarity_pek))

######################################################### PROBLEM 3 #########################################################

print("################################################# SENTIMENT ANALYSIS #################################################\n")

# Coordinates
c_KLIA_KUL = (2.7456, 101.7072) # 0. Kuala Lumpur International Airport, Kuala Lumpur
c_SHIA_JAK = (-6.1275, 106.6537) # 1. Soekarno-Hatta International Airport, Jakarta
c_SUVA_BKK = (13.6900, 100.7501) # 2. Suvarnabhumi Airport, Bangkok
c_CLK_HKG = (22.3080, 113.9185) #  3. Chek Lap Kok International Airport, Hong Kong
c_TAO_TPE = (25.0797, 121.2342)  # 4. Taoyuan International Airport, Taipei
c_HND_TOK = (35.5494, 139.7798) # 5. Haneda International Airport, Tokyo
c_ICN_KOR = (37.4602, 126.4407) # 6. Incheon International Airport, Seoul
c_BDA_PEK = (39.5098, 116.4105) # 7. Beijing Daxing International Airport, Beijing

# # Print total flight distances of each city
# totalDist_jak = (geodesic(c_KLIA_KUL, c_SHIA_JAK).km) + (geodesic(c_SHIA_JAK, c_SUVA_BKK).km) + (geodesic(c_SHIA_JAK, c_CLK_HKG).km) + (geodesic(c_SHIA_JAK, c_TAO_TPE).km) 
# + (geodesic(c_SHIA_JAK, c_HND_TOK).km) + (geodesic(c_SHIA_JAK, c_ICN_KOR).km) + (geodesic(c_SHIA_JAK, c_BDA_PEK).km)
# print("Total distance of Jakarta: {}\n".format(totalDist_jak))

# totalDist_bkk = (geodesic(c_KLIA_KUL, c_SUVA_BKK).km) + (geodesic(c_SHIA_JAK, c_SUVA_BKK).km) + (geodesic(c_SUVA_BKK, c_CLK_HKG).km) + (geodesic(c_SUVA_BKK, c_TAO_TPE).km)
# + (geodesic(c_SUVA_BKK, c_HND_TOK).km) + (geodesic(c_SUVA_BKK, c_ICN_KOR).km) + (geodesic(c_SUVA_BKK, c_BDA_PEK).km)
# print("Total distance of Bangkok: {}\n".format(totalDist_bkk))

# totalDist_hkg = (geodesic(c_KLIA_KUL, c_CLK_HKG).km) + (geodesic(c_SHIA_JAK, c_CLK_HKG).km) + (geodesic(c_SUVA_BKK, c_CLK_HKG).km) + (geodesic(c_CLK_HKG, c_TAO_TPE).km)
# + (geodesic(c_CLK_HKG, c_HND_TOK).km) + (geodesic(c_CLK_HKG, c_ICN_KOR).km) + (geodesic(c_CLK_HKG, c_BDA_PEK).km)
# print("Total distance of Hong Kong: {}\n".format(totalDist_hkg))

# totalDist_tpe = (geodesic(c_KLIA_KUL, c_TAO_TPE).km) + (geodesic(c_SHIA_JAK, c_TAO_TPE).km) + (geodesic(c_SUVA_BKK, c_TAO_TPE).km) + (geodesic(c_CLK_HKG, c_TAO_TPE).km)
# + (geodesic(c_TAO_TPE, c_HND_TOK).km) + (geodesic(c_TAO_TPE, c_ICN_KOR).km) + (geodesic(c_TAO_TPE, c_BDA_PEK).km)
# print("Total distance of Taipei: {}\n".format(totalDist_tpe))

# totalDist_tok = (geodesic(c_KLIA_KUL, c_HND_TOK).km) + (geodesic(c_SHIA_JAK, c_HND_TOK).km) + (geodesic(c_SUVA_BKK, c_HND_TOK).km) + (geodesic(c_CLK_HKG, c_HND_TOK).km)
# + (geodesic(c_TAO_TPE, c_HND_TOK).km) + (geodesic(c_HND_TOK, c_ICN_KOR).km) + (geodesic(c_HND_TOK, c_BDA_PEK).km)
# print("Total distance of Tokyo: {}\n".format(totalDist_tok))

# totalDist_kor = (geodesic(c_KLIA_KUL, c_ICN_KOR).km) + (geodesic(c_SHIA_JAK, c_ICN_KOR).km) + (geodesic(c_SUVA_BKK, c_ICN_KOR).km) + (geodesic(c_CLK_HKG, c_ICN_KOR).km)
# + (geodesic(c_TAO_TPE, c_ICN_KOR).km) + (geodesic(c_HND_TOK, c_ICN_KOR).km) + (geodesic(c_ICN_KOR, c_BDA_PEK).km)
# print("Total distance of Seoul: {}\n".format(totalDist_kor))

# totalDist_pek = (geodesic(c_KLIA_KUL, c_BDA_PEK).km) + (geodesic(c_SHIA_JAK, c_BDA_PEK).km) + (geodesic(c_SUVA_BKK, c_BDA_PEK).km) + (geodesic(c_CLK_HKG, c_BDA_PEK).km)
# + (geodesic(c_TAO_TPE, c_BDA_PEK).km) + (geodesic(c_HND_TOK, c_BDA_PEK).km) + (geodesic(c_ICN_KOR, c_BDA_PEK).km)
# print("Total distance of Beijing: {}\n".format(totalDist_pek))




# Sentiment analysis
# JAK


# Sentiment analysis (polarity/no_of_articles)
sentiment_jak = polarity_jak/6
sentiment_bkk = polarity_bkk/6
sentiment_hkg = polarity_hkg/6
sentiment_tpe = polarity_tpe/6
sentiment_tok = polarity_tok/6
sentiment_kor = polarity_kor/6
sentiment_pek = polarity_pek/6

path_jak = 1/totalDist_jak
path_bkk = 1/totalDist_bkk
path_hkg = 1/totalDist_hkg
path_tpe = 1/totalDist_tpe
path_tok = 1/totalDist_tok
path_kor = 1/totalDist_kor
path_pek = 1/totalDist_pek

# Probability of each cities
ProbabilityJAK = ((sentiment_jak * 0.3)+(path_jak * 0.7))/1
ProbabilityBKK = ((sentiment_bkk * 0.3)+(path_bkk * 0.7))/1
ProbabilityHKG = ((sentiment_hkg * 0.3)+(path_hkg * 0.7))/1
ProbabilityTPE = ((sentiment_tpe * 0.3)+(path_tpe * 0.7))/1
ProbabilityTOK = ((sentiment_tok * 0.3)+(path_tok * 0.7))/1
ProbabilityKOR = ((sentiment_kor * 0.3)+(path_kor * 0.7))/1
ProbabilityPEK = ((sentiment_pek * 0.3)+(path_pek * 0.7))/1

sortBest = [[ProbabilityJAK, "Jakarta"], [ProbabilityBKK, "Bangkok"], [ProbabilityHKG, "Hong Kong"], [ProbabilityTPE, "Taipei"], [ProbabilityTOK, "Tokyo"], [ProbabilityKOR, "Seoul"], [ProbabilityPEK, "Beijing"]]
sortBest.sort(reverse=True)
print("The best path among all routes in descending order (after taking sentiment analysis into consideration):")
print ("{0}".format(sortBest))


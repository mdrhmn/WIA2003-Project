# Removing stop words and punctuations using KMP Algorithm
import string
directory = "/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/"
filesArr = ["jak.txt","bkk.txt","hkg.txt","tpe.txt","tok.txt","kor.txt","pek.txt"]

posWordsDirectory = directory + "poswords.txt"
negWordsDirectory = directory + "negwords.txt"
posnegArr = [posWordsDirectory, negWordsDirectory]

totalCountArr = [0,0,0,0,0,0,0]
# 2D Array; [posCount, negCount] for 7 cities
posnegCountArr = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]]
# posnegWordsArr = [['',''],['',''],['',''],['',''],['',''],['',''],['','']]

index = 0
for i in range(0, len(filesArr), 1):
    fileDirectory = directory + filesArr[index]

    # Open and read cities text file
    with open(fileDirectory, encoding="utf8") as word_list:
        words = word_list.read().lower().split()
    
    index2 = 0
    for i in posnegArr:
        
        # Open and read poswords.txt and negwords.txt
        with open(posnegArr[index2], encoding="utf8") as word_list:
            compareWords = word_list.read().split()

        totalCount = 0

        for i in words:
            # Calculate total number of words
            totalCount = totalCount + 1
            index_j = 0

            # Compare words of cities text file with words in poswords.txt and negwords.txt
            for j in compareWords:
                if i == compareWords[index_j]:
                    posnegCountArr[index][index2] = posnegCountArr[index][index2] + 1
                    # (posnegWordsArr[index][index2]).append(compareWords[index_j])
                
                index_j = index_j + 1
        
        index2 = index2 + 1
        
    totalCountArr[index] = totalCount
    print("Total number of words in {0}: {1}".format(filesArr[index], totalCount))

    print("Number of positive words in {0}: {1}".format(filesArr[index], posnegCountArr[index][0]))
    print("Number of negative words in {0}: {1}".format(filesArr[index], posnegCountArr[index][1]))

    posPercent = (posnegCountArr[index][0]/totalCount)*100
    negPercent = (posnegCountArr[index][1]/totalCount)*100

    print("Percentage of positive words in {}: {:.4f}%".format(filesArr[index], posPercent))
    print("Percentage of negative words in {}: {:.4f}%\n".format(filesArr[index], negPercent))

    index = index + 1
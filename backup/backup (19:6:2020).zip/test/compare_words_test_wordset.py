directory = "/Users/muhdrahiman/Desktop/SE 18:19/S4/[WIA2005] (ALGORITHM DESIGN AND ANALYSIS)/GROUP ASSIGNMENT/QUESTION 2/textfiles/"
filesArr = ["jak.txt","bkk.txt","hkg.txt","tpe.txt","tok.txt","kor.txt","pek.txt"]

# Word sets
# JAKARTA: 
jak_pos = ['growth','grow','grew','optimistic','sufficient','highest','higher','expanded','rise','rising','high-income','easing','growth','supporting','supported','equitable','maintain','sufficient','better','advantage']
jak_neg = ['shave','downturn','fell','slowdown','lowest','risk','fall','weakening','weaken','deficit','worsen','worst','burden','stress','downfall','decline','risk','risks','declining','decline']

# BANGKOK: 
bkk_pos = ['normal', 'maintain', 'strong', 'plan', 'plans' 'positive', 'increased', 'spike', 'rise', 'sufficient', 'stable', 'reliable', 'manageable', 'surged', 'spiked', 'soared', 'rose', 'relief', 'expand', 'accelerated']
bkk_neg = ['risks', 'irregularity', 'falling', 'weak', 'weakest', 'damage', 'damaging', 'reeling', 'collapse', 'drop', 'loss', 'losses', 'slowdown', 'risk', 'negative', 'critical', 'slower', 'fell', 'stop', 'fall']

# HONG KONG: 
hkg_pos = ['rise', 'maintain', 'supporting', 'stability', 'recover', 'bounce', 'restore', 'save', 'fund', 'boost', 'stimulating', 'increase', 'increased', 'rebooting', 'developing', 'develop', 'relieve', 'grow', 'better', 'stimulate']
hkg_neg = ['deteriorating', 'falling', 'worse', 'weakening', 'slowing', 'unemployment', 'threat', 'deficit', 'risk', 'reduced', 'lower', 'weakening', 'crisis', 'recession', 'downturn', 'unrest', 'fell',  'slowing', 'reeling', 'critical']

# TAIPEI: 
tpe_pos = ['ramped', 'authorised', 'growing', 'expand', 'increase', 'sufficient', 'secure', 'high', 'shoring', 'stability', 'revive', 'maintaining', 'soared', 'rise', 'rising', 'increased', 'surged', 'strong',  'maintain', 'revised']
tpe_neg = ['lowered', 'downgrade', 'uncertainty', 'cut', 'crisis', 'canceled', 'fallen', 'losses', 'subsides', 'slow', 'low', 'recession', 'worst', 'interrupt', 'reduced', 'fell', 'dropped', 'plunge', 'lower', 'downgraded']

# TOKYO: 
tok_pos = ['deploy','raising','raised','raises','greater','recovering','expanded','improvement','improve','expansion','expanding','forestall','funded','protected','overcome','helped','upgrades','improved','recouped','recovery']
tok_neg = ['stagnation','crisis','stagnate','risks','recession','losses','hurt','loss','cancellation','worse','risk','conflicts','worsens','delayed','negative','lower','sicker','bad','drop','disruption']

# SEOUL: 
kor_pos = ['recovery','raise','prevention','recover','rebound','improved','efforts','stronger','additional','rose','expansionary','ensure','helped','stabilization','improving','expended','improvement','sufficiently','substantial','gain']
kor_neg = ['suffer','suffered','recession','severe','setbacks','suspended','warns','delaying','delayed','shutdowns','damage','critical','fallout','dropped','problematic','crisis','negatively','hit','worse','falling']

# BEIJING: 
pek_pos = ['growth','recovery','supporting','increasing','stabilizing','maintained','grow','grew','improvement','upwards','boost','upgraded','achieving','stability','increasing','sustainably','expand','recovery','strengthened','positively']
pek_neg = ['decline','collapse','imbalance','dropped','fell','debt','contract','drop','bottom','weak','suffered','stressed','risk','scandals','degradation','tension','declines','difficult','reducing','weaker']

# 2D Array: [posWords, negWords] for all 7 cities
posnegArr = [[jak_pos, jak_neg], [bkk_pos, bkk_neg], [hkg_pos, hkg_neg], [tpe_pos, tpe_neg], [tok_pos, tok_neg], [kor_pos, kor_neg], [pek_pos, pek_neg]]

# 2D Array; [posCount, negCount] for 7 cities
posnegCountArr = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]]

totalCountArr = [0,0,0,0,0,0,0]

# Positive and negative word frequencies for each city
jak_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
jak_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
bkk_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
bkk_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
hkg_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
hkg_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
tpe_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
tpe_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
tok_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
tok_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
kor_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
kor_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
pek_pos_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
pek_neg_f = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

# 2D Array; [posFreq, negFreq] for 7 cities
posnegFrequencyArr = [[jak_pos_f, jak_neg_f], [bkk_pos_f, bkk_neg_f], [hkg_pos_f, hkg_neg_f], [tpe_pos_f, tpe_neg_f], [tok_pos_f, tok_neg_f], [kor_pos_f, kor_neg_f], [pek_pos_f, pek_neg_f]]

index = 0
# First loop: Loops between cities text file
for i in range(0, len(filesArr), 1):
    fileDirectory = directory + filesArr[index]

    # Open and read cities text file
    with open(fileDirectory, encoding="utf8") as word_list:
        words = word_list.read().lower().split()
    
    index2 = 0
    # Second loop: Loops between cities' sets of positive and negative words
    for j in posnegArr:

        totalCount = 0
        # Third loop: Compare the words
        for k in words:
            totalCount = totalCount + 1

            if k in posnegArr[index][index2]:
                posnegCountArr[index][index2] = posnegCountArr[index][index2] + 1
                posnegFrequencyArr[index][index2][(posnegArr[index][index2]).index(k)] = posnegFrequencyArr[index][index2][(posnegArr[index][index2]).index(k)] + 1
     
        if (index2 + 1 < 2):
            index2 = index2 + 1
        else:
            break
        
    totalCountArr[index] = totalCount
    print("Total number of words in {0}: {1}".format(filesArr[index], totalCount))

    print("Number of positive words in {0}: {1}".format(filesArr[index], posnegCountArr[index][0]))
    print("Positive word sets:\n{0}\nFrequency:\n{1}\n".format(posnegArr[index][0], posnegFrequencyArr[index][0]))
    
    print("Number of negative words in {0}: {1}".format(filesArr[index], posnegCountArr[index][1]))
    print("Negative word sets:\n{0}\nFrequency:\n{1}\n".format(posnegArr[index][1], posnegFrequencyArr[index][1]))
   
   posPercent = (posnegCountArr[index][0]/totalCount)*100
    negPercent = (posnegCountArr[index][1]/totalCount)*100

    print("Percentage of positive words in {}: {:.4f}%".format(filesArr[index], posPercent))
    print("Percentage of negative words in {}: {:.4f}%\n".format(filesArr[index], negPercent))

    index = index + 1

    
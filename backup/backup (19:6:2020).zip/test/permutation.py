#Prints the array 
def printArr(a, n): 
    for i in range(n): 
        l = [] # empty list that will store current permutation 
        l.append(a[i])
        # print(a[i],end=" ") 
    # print() 
  
# Generating permutation using Heap Algorithm 
def heapPermutation(a, size, n): 
      
    # if size becomes 1 then prints the obtained 
    # permutation 
    if (size == 1): 
        printArr(a, n) 
        return
  
    for i in range(size): 
        heapPermutation(a,size-1,n); 
  
        # if size is odd, swap first and last 
        # element 
        # else If size is even, swap ith and last element 
        if size&1: 
            a[0], a[size-1] = a[size-1],a[0] 
        else: 
            a[i], a[size-1] = a[size-1],a[i] 
          
# Driver code 
# List of cities 
cityName = ['JAK', 'BKK', 'HKG', 'TPE', 'TOK', 'KOR', 'PEK']
city = [1,2,3,4,5,6,7]

sentBest = [3.029, 2.778, -1.449, -1.453, -1.680, -1.768, -1.927]
sentimentRoutes = []*5040

path = heapPermutation(city, len(city), len(city)) # Generating all possible path using permutation
pathName = heapPermutation(cityName, len(cityName), len(cityName))
import matplotlib.pyplot as plt
import networkx as nx
from geopy.distance import geodesic
from gmplot import *

################################################## GRAPH 1 (UMC-->TBS) ##########################################################################

G = nx.Graph()

# Coordinates
c_KLIA_KUL = (2.7456, 101.7072) # 0. Kuala Lumpur International Airport, Kuala Lumpur
c_SHIA_JAK = (-6.1275, 106.6537) # 1. Soekarno-Hatta International Airport, Jakarta
c_SUVA_BKK = (13.6900, 100.7501) # 2. Suvarnabhumi Airport, Bangkok
c_CLK_HKG = (22.3080, 113.9185) # 3. Chek Lap Kok International Airport, Hong Kong
c_TAO_TPE = (25.0797, 121.2342)  # 4. Taoyuan International Airport, Taipei
c_HND_TOK = (35.5494, 139.7798) # 5. Haneda International Airport, Tokyo
c_ICN_KOR = (37.4602, 126.4407) # 6. Incheon International Airport, Seoul
c_BDA_PEK = (39.5098, 116.4105) # 7. Beijing Daxing International Airport, Beijing

# KUL edges
G.add_edge("KUL", "JAK", weight = (geodesic(c_KLIA_KUL, c_SHIA_JAK).km))
G.add_edge("KUL", "BKK", weight = (geodesic(c_KLIA_KUL, c_SUVA_BKK).km))
G.add_edge("KUL", "HKG", weight = (geodesic(c_KLIA_KUL, c_CLK_HKG).km))
G.add_edge("KUL", "TPE", weight = (geodesic(c_KLIA_KUL, c_TAO_TPE).km))
G.add_edge("KUL", "HND", weight = (geodesic(c_KLIA_KUL, c_HND_TOK).km)) 
G.add_edge("KUL", "ICN", weight = (geodesic(c_KLIA_KUL, c_ICN_KOR).km)) 
G.add_edge("KUL", "PEK", weight = (geodesic(c_KLIA_KUL, c_BDA_PEK).km)) 

# JAK edges_
G.add_edge("JAK", "BKK", weight = (geodesic(c_SHIA_JAK, c_SUVA_BKK).km))
G.add_edge("JAK", "HKG", weight = (geodesic(c_SHIA_JAK, c_CLK_HKG).km))
G.add_edge("JAK", "TPE", weight = (geodesic(c_SHIA_JAK, c_TAO_TPE).km))
G.add_edge("JAK", "HND", weight = (geodesic(c_SHIA_JAK, c_HND_TOK).km))
G.add_edge("JAK", "ICN", weight = (geodesic(c_SHIA_JAK, c_ICN_KOR).km)) 
G.add_edge("JAK", "PEK", weight = (geodesic(c_SHIA_JAK, c_BDA_PEK).km))

# BKK edges
G.add_edge("BKK", "HKG", weight = (geodesic(c_SUVA_BKK, c_CLK_HKG).km))
G.add_edge("BKK", "TPE", weight = (geodesic(c_SUVA_BKK, c_TAO_TPE).km))
G.add_edge("BKK", "HND", weight = (geodesic(c_SUVA_BKK, c_HND_TOK).km))
G.add_edge("BKK", "ICN", weight = (geodesic(c_SUVA_BKK, c_ICN_KOR).km))
G.add_edge("BKK", "PEK", weight = (geodesic(c_SUVA_BKK, c_BDA_PEK).km)) 

# HKG edges
G.add_edge("HKG", "TPE", weight = (geodesic(c_CLK_HKG, c_TAO_TPE).km))
G.add_edge("HKG", "HND", weight = (geodesic(c_CLK_HKG, c_HND_TOK).km))
G.add_edge("HKG", "ICN", weight = (geodesic(c_CLK_HKG, c_ICN_KOR).km))
G.add_edge("HKG", "PEK", weight = (geodesic(c_CLK_HKG, c_BDA_PEK).km))

# TPE edges
G.add_edge("TPE", "HND", weight = (geodesic(c_TAO_TPE, c_HND_TOK).km))
G.add_edge("TPE", "ICN", weight = (geodesic(c_TAO_TPE, c_ICN_KOR).km))
G.add_edge("TPE", "PEK", weight = (geodesic(c_TAO_TPE, c_BDA_PEK).km))

# HND edges
G.add_edge("HND", "ICN", weight = (geodesic(c_HND_TOK, c_ICN_KOR).km))
G.add_edge("HND", "PEK", weight = (geodesic(c_HND_TOK, c_BDA_PEK).km)) 

# ICN edges
G.add_edge("ICN", "PEK", weight = (geodesic(c_ICN_KOR, c_BDA_PEK).km))

elarge = [(u, v) for (u, v, d) in G.edges(data=True) if d['weight'] >= 0]

pos = nx.spring_layout(G)  # positions for all nodes

# nodes
nx.draw_networkx_nodes(G, pos, node_size=800)

# edges labels
edge_labels = nx.draw_networkx_edge_labels(G, pos, edge_labels = nx.get_edge_attributes(G,'weight'), font_size=7)

# edges
nx.draw_networkx_edges(G, pos, edgelist=elarge, width=4)

# labels
nx.draw_networkx_labels(G, pos, font_size=10, font_family='sans-serif')

plt.axis('off')
plt.show()
import numpy as np
import matplotlib.pyplot as plt
 
totalCount_jak = 1587
totalCount_bkk = 1883
totalCount_hkg = 3205
totalCount_tpe = 2069
totalCount_tok = 3009
totalCount_kor = 2414
totalCount_pek = 2513

# Make a fake dataset
totalCount = [totalCount_jak, totalCount_bkk, totalCount_hkg, totalCount_tpe, totalCount_tok, totalCount_kor, totalCount_pek]
labels = ('Jakarta', 'Bangkok', 'Hong Kong', 'Taipei', 'Tokyo', 'Seoul', 'Beijing')
y_pos = np.arange(len(labels))
plt.scatter(y_pos, totalCount, color=['black', 'red', 'green', 'blue', 'cyan','yellow','orange'])
# plt.xticks(y_pos, labels)

plt.title('Word Count for Every City')
plt.xlabel('Cities')
plt.ylabel('Number of Words')
plt.plot(labels, totalCount, '-', label='Sample Label Red')
plt.legend()

for x,y in zip(labels,totalCount):

    label = "{:.2f}".format(y)

    plt.annotate(label, # this is the text
                 (x,y), # this is the point to label
                 textcoords="offset points", # how to position the text
                 xytext=(0,10), # distance from text to points (x,y)
                 ha='center')
plt.show()



# totalCount = [jak_totalCount, bkk_totalCount, hkg_totalCount, tpe_totalCount, tok_totalCount, kor_totalCount, pek_totalCount]
# plt.plot( 'x', 'y', data=vals, linestyle='-', marker='o')
# plt.show()

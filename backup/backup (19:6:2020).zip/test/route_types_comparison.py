import numpy as np
import matplotlib.pyplot as plt

# SHORTEST DISTANCE:
# Route               : ['KUL', 'BKK', 'PEK', 'KOR', 'TOK', 'TPE', 'HKG', 'JAK', 'KUL']
# Distance [0001]     : 13875.440442360568 km
# Sentiment [2645]    : -30

# BEST SENTIMENT:
# Route               : ['KUL', 'JAK', 'PEK', 'TOK', 'BKK', 'HKG', 'KOR', 'TPE', 'KUL']
# Distance [1578]     : 21422.180950592334 km
# Sentiment [0001]    : 0

# MOST OPTIMISED:
# Route               : ['KUL', 'JAK', 'BKK', 'PEK', 'KOR', 'TOK', 'HKG', 'TPE', 'KUL']
# Distance [0102]     : 15724.175657669719 km
# Sentiment [0182]    : -13

# data to plot
n_groups = 3
distance = (13875.440442360568, 21422.180950592334, 15724.175657669719)
sentiment = (30, 0, 13)

# create plot
fig, ax1 = plt.subplots()
index = np.arange(n_groups)
bar_width = 0.35
opacity = 0.8

ax1.set_xlabel('Possible Routes (5040)')
plt.title('Comparison of 3 Types of Routes')
plt.xticks(index + bar_width/2, ('Shortest Distance', 'Best Sentiment', 'Optimised'))
plt.xlabel('Types of Routes')

color = 'tab:blue'
ax1.set_ylabel('Distance', color=color)  # we already handled the x-label with ax1
rects1 = ax1.bar(index, distance, bar_width,
alpha=opacity,
color='b',
label='Distance (km)')
ax1.tick_params(axis='y', labelcolor=color)

ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis

color = 'tab:red'
ax2.set_ylabel('Sentiment Measure', color=color)
rects2 = ax2.bar(index + bar_width, sentiment, bar_width,
alpha=opacity,
color='r',
label='Sentiment Measure')
ax2.tick_params(axis='y', labelcolor=color)

# Label values of each bar
for rect in rects1:
    h = rect.get_height()
    ax1.text(rect.get_x()+rect.get_width()/2., h, '%d'%int(h),
            ha='center', va='bottom')

for rect in rects2:
    h = rect.get_height()
    ax2.text(rect.get_x()+rect.get_width()/2., h, '%d'%int(h),
            ha='center', va='bottom')

fig.tight_layout()  # otherwise the right y-label is slightly clipped
plt.show()
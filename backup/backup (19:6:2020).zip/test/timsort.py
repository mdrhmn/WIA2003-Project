arr = [3.0289330922242312, -1.4534055286406384, 2.7777777777777777, -
       1.7669795692987302, -1.4489953632148378, -1.6802800466744459, -1.9270678920841982]


def InsertionSort(array):
    for x in range(1, len(array)):
        for i in range(x, 0, -1):
            if array[i] > array[i - 1]:
                t = array[i]
                array[i] = array[i - 1]
                array[i - 1] = t
            else:
                break
            i = i - 1
    return array


print(arr)
InsertionSort(arr)
print(arr)
